/* Optional extension point. Disabled by default. Never put a secret API key in public frontend code. */
window.AI_EXPLAIN_CONFIG = { enabled: false, endpoint: "", apiKey: "" };
window.aiExplain = async function(message, localResult) {
  if (!window.AI_EXPLAIN_CONFIG.enabled || !window.AI_EXPLAIN_CONFIG.endpoint) return localResult;
  // A public website must call your own protected backend; do not expose API keys here.
  try {
    const response = await fetch(window.AI_EXPLAIN_CONFIG.endpoint, {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({message, localResult})
    });
    if (!response.ok) throw new Error("AI endpoint unavailable");
    return await response.json();
  } catch (error) {
    console.warn("Optional AI explanation unavailable; using offline result.", error);
    return localResult;
  }
};