/* Offline, rule-based detection. Heuristics are indicators, not proof. */
(function(){
  const norm = s => (s || "").toLowerCase().normalize("NFKC");
  function scanMessage(message) {
    const text = norm(message);
    const matched = [];
    const warnings = [];
    let score = 0;
    const addWarning = (label, points) => { score += points; warnings.push({label, points}); };
    (window.SCAM_CATEGORIES || []).forEach(cat => {
      const hits = cat.keywords.filter(k => text.includes(norm(k)));
      if (hits.length) {
        matched.push({...cat, hits});
        score += Math.min(cat.weight, cat.weight * Math.min(hits.length, 2) / 1.5);
      }
    });
    const rules = [
      {re:/\b(otp|one.time.password|upi pin|cvv|password)\b|ઓટીપી|પિન જણાવો/i, label:"OTP/PIN/પાસવર્ડની માંગ", points:28},
      {re:/urgent|immediately|within 24 hours|last warning|તાત્કાલિક|આજે જ/i, label:"તાત્કાલિક કાર્યવાહીનું દબાણ", points:10},
      {re:/arrest|legal action|account.*blocked|disconnect|ધરપકડ|બંધ થઈ જશે|કનેક્શન કપાશે/i, label:"ધમકી અથવા ડર ઊભો કરવો", points:12},
      {re:/pay.*fee|processing fee|deposit|send money|₹\s?\d|rs\.?\s?\d|પૈસા મોકલો|ફી ભરો/i, label:"પૈસા અથવા ફીની માંગ", points:12},
      {re:/https?:\/\/|www\.|bit\.ly|tinyurl|cutt\.ly/i, label:"મેસેજમાં લિંક છે", points:10},
      {re:/\.xyz\b|\.top\b|\.click\b|\.online\b|\.info\b|sbi-kyc-update/i, label:"શંકાસ્પદ ડોમેન હોઈ શકે છે", points:18},
      {re:/\.apk\b|install this app|download this app|એપ ઇન્સ્ટોલ/i, label:"એપ/APK ઇન્સ્ટોલ કરવા કહે છે", points:18},
      {re:/do not tell anyone|don't tell anyone|કોઈને કહેશો નહીં/i, label:"ગુપ્ત રાખવા દબાણ", points:12}
    ];
    rules.forEach(r => { if (r.re.test(message)) addWarning(r.label, r.points); });
    const urls = (message.match(/(?:https?:\/\/|www\.)[^\s<>"']+/gi) || []).map(u => u.replace(/[),.!?]+$/,""));
    const links = urls.map(url => {
      const reasons = [];
      if (/bit\.ly|tinyurl|cutt\.ly/i.test(url)) reasons.push("ટૂંકી કરેલી લિંક");
      if (/\.xyz|\.top|\.click|\.online|\.info/i.test(url)) reasons.push("અસામાન્ય ડોમેન");
      if (/^http:\/\//i.test(url)) reasons.push("એન્ક્રિપ્શન વગરની HTTP લિંક");
      if (/\d{1,3}(?:\.\d{1,3}){3}/.test(url)) reasons.push("IP સરનામાવાળી લિંક");
      return {url, suspicious: reasons.length > 0, reasons: reasons.length ? reasons : ["ફક્ત લખાણ પરથી લિંક સલામત છે તે નક્કી કરી શકાતું નથી"]};
    });
    // A genuine "never share OTP" warning should not be treated like an OTP theft request.
    const protective = /do not share|never share|કોઈને.*નહીં આપો|શેર કરશો નહીં|ક્યારેય.*otp.*નહીં/i.test(message);
    const asksForSecret = /share otp|send otp|tell.*otp|upi pin|cvv|password|ઓટીપી.*આપો|પિન જણાવો/i.test(message);
    if (protective && !asksForSecret && matched.length === 0) score = Math.min(score, 8);
    // Avoid classifying an ordinary bank debit alert as risky without a link/request.
    const normalDebit = /debited from|credited to|a\/c\s?\*{0,2}\w+|ref(?:erence)?\s?\d+/i.test(message) && !urls.length && !asksForSecret;
    if (normalDebit && matched.length === 0) score = Math.min(score, 8);
    score = Math.max(0, Math.min(100, Math.round(score)));
    const level = score >= 60 ? "danger" : score >= 30 ? "suspicious" : "safe";
    if (!matched.length && score >= 30) matched.push({id:"general",nameGu:"સામાન્ય શંકાસ્પદ સંકેતો",nameEn:"General warning signs",explainGu:"મેસેજમાં કેટલીક સામાન્ય જોખમી બાબતો દેખાય છે."});
    if (!matched.length && score < 30) matched.push({id:"none",nameGu:"કોઈ સ્પષ્ટ છેતરપિંડીના સંકેત મળ્યા નથી",nameEn:"No clear scam signs",explainGu:"આ તપાસમાં સ્પષ્ટ છેતરપિંડીના સંકેત મળ્યા નથી. તેમ છતાં મોકલનારને ઓળખતા ન હો તો સાવચેત રહો."});
    if (links.some(l=>l.suspicious) && !warnings.some(w=>w.label.includes("ડોમેન"))) warnings.push({label:"લિંકના ડોમેનમાં શંકાસ્પદ સંકેત",points:0});
    return {score, level, matched, warnings, links, original:message, confidence: Math.min(96, 52 + matched.length*12 + warnings.length*3)};
  }
  window.ScamEngine = {scanMessage};
})();