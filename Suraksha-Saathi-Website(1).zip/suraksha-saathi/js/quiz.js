(function(){
const questions=[
{m:"Your SBI account will be blocked. Update KYC at http://sbi-kyc-update.xyz",scam:true,why:"બેંક ખાતું બંધ કરવાની ધમકી અને શંકાસ્પદ લિંક છે."},
{m:"Rs 500 debited from your account. Ref 123456. If not you, contact your bank using the official app.",scam:false,why:"આ સામાન્ય ડેબિટ એલર્ટ જેવું લાગે છે અને તેમાં અજાણી લિંક કે ગુપ્ત માહિતીની માંગ નથી."},
{m:"Congratulations! You won a prize. Pay ₹2,000 processing fee.",scam:true,why:"ઇનામ મેળવવા ફી માંગવી સામાન્ય છેતરપિંડીનો સંકેત છે."},
{m:"Your OTP is 482913. Do not share it with anyone.",scam:false,why:"આ મેસેજ OTP શેર ન કરવા ચેતવે છે; તે પોતે OTP માંગતો નથી."},
{m:"Enter your UPI PIN to receive a refund.",scam:true,why:"પૈસા મેળવવા UPI PIN દાખલ કરવાની જરૂર નથી."},
{m:"Install this APK to view your wedding invitation.",scam:true,why:"અજાણી APK ફાઇલમાં જોખમી સોફ્ટવેર હોઈ શકે છે."},
{m:"Your appointment is confirmed for 3 PM. Please arrive 10 minutes early.",scam:false,why:"મેસેજમાં પૈસા, ગુપ્ત માહિતી કે અજાણી લિંકની માંગ નથી."},
{m:"CBI has found drugs in your parcel. Stay on video call or you will be arrested.",scam:true,why:"ધરપકડની ધમકી અને વીડિયો કૉલ દ્વારા ડરાવવું ડિજિટલ અરેસ્ટ scamનો સંકેત છે."},
{m:"Earn ₹5000 daily by liking videos. Deposit money to unlock the next task.",scam:true,why:"અસામાન્ય કમાણી અને કામ ચાલુ રાખવા ડિપોઝિટની માંગ જોખમી છે."},
{m:"Hi Mom, this is my new number. Urgently send money; don't call, I'm busy.",scam:true,why:"નવો નંબર, તાત્કાલિક પૈસા અને ફોન ન કરવા કહેવું — સગા હોવાનો દાવો અલગથી ચકાસો."}
];
let i=0,score=0,answered=false;
const $=id=>document.getElementById(id);
function draw(){answered=false;$("questionCount").textContent="પ્રશ્ન "+(i+1)+" / "+questions.length;$("quizMeter").style.width=(i/questions.length*100)+"%";$("quizMessage").textContent=questions[i].m;$("quizFeedback").textContent="";$("quizFeedback").className="quiz-feedback";$("nextQuestion").hidden=true;$("scamAnswer").disabled=false;$("safeAnswer").disabled=false;}
function answer(value){if(answered)return;answered=true;const q=questions[i];const ok=value===q.scam;if(ok)score++;$("quizFeedback").textContent=(ok?"સાચો જવાબ! ✓ ":"આ જવાબ સાચો નથી. ")+q.why;$("quizFeedback").classList.add(ok?"correct":"incorrect");$("scamAnswer").disabled=true;$("safeAnswer").disabled=true;$("nextQuestion").hidden=false;$("nextQuestion").textContent=i===questions.length-1?"પરિણામ જુઓ →":"આગળનો પ્રશ્ન →";}
document.addEventListener("DOMContentLoaded",()=>{draw();$("scamAnswer").addEventListener("click",()=>answer(true));$("safeAnswer").addEventListener("click",()=>answer(false));$("nextQuestion").addEventListener("click",()=>{if(i<questions.length-1){i++;draw();}else{$("quizPanel").hidden=true;$("quizFinal").hidden=false;$("finalScore").textContent="તમારો સ્કોર: "+score+" / "+questions.length+" ("+Math.round(score/questions.length*100)+"%)";$("quizMeter").style.width="100%";}});$("restartQuiz").addEventListener("click",()=>{i=0;score=0;$("quizPanel").hidden=false;$("quizFinal").hidden=true;draw();});});
})();