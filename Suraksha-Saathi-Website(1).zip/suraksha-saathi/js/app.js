(function(){
const $ = id => document.getElementById(id);
const samples = [
"Dear customer your SBI account will be blocked today. Update KYC now: http://sbi-kyc-update.xyz",
"Your OTP is 482913. Do not share it with anyone.",
"Congratulations! You won ₹25,00,000 in KBC. Pay ₹5,000 processing fee.",
"Earn ₹5000 daily by liking videos. Join Telegram group.",
"Aapka parcel me drugs mila hai, CBI officer se video call par baat karo.",
"Rs 500 debited from A/c XX1234 on 12-10 via UPI. Ref 123456.",
"તમારું લાઇટ બિલ બાકી છે, આજે રાત્રે કનેક્શન કપાશે. આ નંબર પર કૉલ કરો 98XXXXXXXX",
"Enter your UPI PIN to receive ₹2000 refund",
"Your e-challan of ₹500 is pending, pay at http://echallan-parivahan.top",
"Hi Mom, this is my new number, urgent need money",
"Your credit card reward points expire today. Click this unknown link to claim.",
"Install wedding_invitation.apk to see the wedding card."
];
let lastResult = null, fontLarge = false, lang = "gu";
const translations = {
gu:{navCheck:"તપાસો",navLearn:"શીખો",navQuiz:"ક્વિઝ",heroTitle:"મેસેજ સાચો છે કે છેતરપિંડી?",heroText:"શંકાસ્પદ SMS, WhatsApp, ઈમેલ અથવા પેમેન્ટ મેસેજ અહીં તપાસો. સરળ ભાષામાં જોખમ અને સુરક્ષિત આગળનાં પગલાં જાણો.",pasteTitle:"શંકાસ્પદ મેસેજ અહીં પેસ્ટ કરો",pasteHelp:"OTP, PIN કે સંપૂર્ણ કાર્ડ વિગતો ધરાવતો મેસેજ અહીં શેર કરવાની જરૂર નથી.",private:"તમારો મેસેજ તમારા બ્રાઉઝરમાં જ તપાસાય છે",messagePlaceholder:"ઉદાહરણ: તમારું બેંક ખાતું બંધ થઈ જશે. KYC અપડેટ કરવા અહીં ક્લિક કરો...",checkBtn:"મેસેજ તપાસો"},
en:{navCheck:"Check",navLearn:"Learn",navQuiz:"Quiz",heroTitle:"Is this message real or a scam?",heroText:"Check suspicious SMS, WhatsApp, email or payment messages. Understand the risk and safe next steps.",pasteTitle:"Paste a suspicious message here",pasteHelp:"You do not need to share messages containing real OTPs, PINs or full card details.",private:"Your message is checked in your browser",messagePlaceholder:"Example: Your bank account will be blocked. Click here to update KYC...",checkBtn:"Check message"},
hi:{navCheck:"जाँचें",navLearn:"सीखें",navQuiz:"क्विज़",heroTitle:"यह संदेश असली है या धोखाधड़ी?",heroText:"संदिग्ध SMS, WhatsApp, ईमेल या भुगतान संदेश की जाँच करें और सुरक्षित कदम जानें।",pasteTitle:"संदिग्ध संदेश यहाँ पेस्ट करें",pasteHelp:"असली OTP, PIN या कार्ड की पूरी जानकारी साझा करने की ज़रूरत नहीं है।",private:"आपका संदेश आपके ब्राउज़र में जाँचा जाता है",messagePlaceholder:"उदाहरण: आपका बैंक खाता बंद हो जाएगा। KYC अपडेट करने के लिए क्लिक करें...",checkBtn:"संदेश जाँचें"}
};
function initCommon(){
 const sel=$("languageSelect"); if(sel) sel.addEventListener("change",()=>{lang=sel.value;document.documentElement.lang=lang;document.querySelectorAll("[data-i18n]").forEach(el=>{const key=el.dataset.i18n;if(translations[lang][key])el.textContent=translations[lang][key]});document.querySelectorAll("[data-i18n-placeholder]").forEach(el=>{const key=el.dataset.i18nPlaceholder;if(translations[lang][key])el.placeholder=translations[lang][key]})});
 const ft=$("fontToggle"); if(ft) ft.addEventListener("click",()=>{fontLarge=!fontLarge;document.body.classList.toggle("large-text",fontLarge);ft.textContent=fontLarge?"A−":"A+"});
 const mt=$("menuToggle"); if(mt) mt.addEventListener("click",()=>{$("mainNav").classList.toggle("nav-open")});
}
function escapeHTML(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function renderSamples(){const box=$("sampleMessages");if(!box)return; samples.slice(0,12).forEach((s,i)=>{const b=document.createElement("button");b.className="sample-button";b.textContent=["Bank KYC","OTP warning","Lottery","Job task","Digital arrest","Bank debit","Electricity bill","UPI refund","E-challan","Family emergency","Card reward","Wedding APK"][i];b.addEventListener("click",()=>{ $("messageInput").value=s; updateCount(); $("messageInput").focus();});box.appendChild(b);});}
function updateCount(){const el=$("messageInput");if(el)$("charCount").textContent=el.value.length+" / 12000";}
function check(){const input=$("messageInput"), err=$("inputError");if(!input)return;const message=input.value.trim();err.textContent="";if(!message){err.textContent="કૃપા કરીને પહેલાં મેસેજ પેસ્ટ કરો.";input.focus();return;}if(message.length>12000){err.textContent="મેસેજ ખૂબ લાંબો છે. કૃપા કરીને ટૂંકો કરો.";return;}lastResult=window.ScamEngine.scanMessage(message);renderResult(lastResult);}
function renderResult(r){
 $("results").hidden=false; const danger=r.level==="danger", suspicious=r.level==="suspicious";
 $("riskIcon").textContent=danger?"🔴":suspicious?"🟡":"🟢"; $("riskLabel").textContent=danger?"ખૂબ જોખમી":suspicious?"શંકાસ્પદ":"સુરક્ષિત લાગે છે"; $("riskLabel").className="risk-label "+r.level;
 $("riskScore").textContent=r.score; $("meterFill").style.width=r.score+"%"; $("meterFill").className=r.level;
 $("riskSummary").textContent=danger?"આ મેસેજમાં ગંભીર જોખમી સંકેતો છે. કોઈ લિંક ખોલશો નહીં અથવા પૈસા મોકલશો નહીં.":suspicious?"કેટલાક સંકેતો શંકાસ્પદ છે. સત્તાવાર માધ્યમથી ચકાસો.":"સ્પષ્ટ જોખમ ઓછું દેખાય છે, પરંતુ આ પરિણામ સલામતીની ગેરંટી નથી.";
 $("confidence").textContent="સંકેત આધારિત અંદાજ: "+r.confidence+"% (ચોક્કસ ખાતરી નહીં)";
 $("scamTypes").innerHTML=r.matched.map(c=>'<span class="scam-chip">'+escapeHTML(c.nameGu||c.nameEn)+'</span>').join("");
 const warnings=r.warnings.map(w=>w.label); r.matched.forEach(c=>warnings.push(c.explainGu)); if(!warnings.length)warnings.push("કોઈ સ્પષ્ટ જોખમી પેટર્ન મળ્યો નથી. મોકલનારને ઓળખતા ન હો તો સાવચેત રહો.");
 $("warningList").innerHTML=[...new Set(warnings)].map(x=>"<li>"+escapeHTML(x)+"</li>").join("");
 $("linkList").innerHTML=r.links.length?r.links.map(l=>'<div class="link-item '+(l.suspicious?"link-danger":"")+'"><strong>'+escapeHTML(l.url)+'</strong><span>'+(l.suspicious?"⚠ શંકાસ્પદ: ":"ℹ ")+escapeHTML(l.reasons.join(", "))+'</span></div>').join(""):'<p class="muted">આ મેસેજમાં ઓળખી શકાય તેવી URL મળી નથી.</p>';
 const terms=[...new Set([...(r.warnings.map(w=>w.label)),...r.matched.flatMap(c=>c.hits||[])])].filter(Boolean);
 let html=escapeHTML(r.original); terms.sort((a,b)=>b.length-a.length).slice(0,20).forEach(term=>{if(term.length>2){const safe=term.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");try{html=html.replace(new RegExp("("+safe+")","ig"),"<mark>$1</mark>")}catch(e){}}});
 $("highlightedMessage").innerHTML=html.replace(/\n/g,"<br>");
 const allDo=["અધિકૃત એપ અથવા વેબસાઇટ જાતે ખોલીને ચકાસો.","OTP, PIN, CVV અથવા પાસવર્ડ કોઈને ન આપો.","શંકાસ્પદ મેસેજનો સ્ક્રીનશૉટ રાખો અને મોકલનારને રિપોર્ટ કરો."];
 const allDont=["અજાણી લિંક પર ક્લિક ન કરો.","અજાણી APK અથવા સ્ક્રીન-શેરિંગ એપ ઇન્સ્ટોલ ન કરો.","ઇનામ, નોકરી, રિફંડ કે પાર્સલ માટે અજાણ્યા વ્યક્તિને ફી ન આપો."];
 $("doList").innerHTML=allDo.map(x=>"<li>"+x+"</li>").join("");$("dontList").innerHTML=allDont.map(x=>"<li>"+x+"</li>").join("");
 $("results").scrollIntoView({behavior:"smooth",block:"start"});
}
function reportText(){if(!lastResult)return "";return "સુરક્ષા સાથી તપાસ પરિણામ\nજોખમ: "+$("riskLabel").textContent+" ("+lastResult.score+"/100)\nપ્રકાર: "+lastResult.matched.map(c=>c.nameGu).join(", ")+"\nસંકેતો: "+lastResult.warnings.map(w=>w.label).join("; ")+"\nસાવચેતી: OTP/PIN/CVV શેર ન કરો અને અજાણી લિંક ન ખોલો.\nફરિયાદ માટે 1930 અથવા https://cybercrime.gov.in/";}
document.addEventListener("DOMContentLoaded",()=>{
 initCommon();renderSamples();const input=$("messageInput");if(input){input.addEventListener("input",updateCount);$("checkBtn").addEventListener("click",check);$("clearBtn").addEventListener("click",()=>{input.value="";updateCount();$("inputError").textContent="";$("results").hidden=true;});$("pasteBtn").addEventListener("click",async()=>{try{input.value=await navigator.clipboard.readText();updateCount();}catch(e){$("inputError").textContent="Clipboard access ઉપલબ્ધ નથી. Ctrl+V વાપરો.";}});$("demoBtn").addEventListener("click",()=>{input.value=samples[0];updateCount();check();});$("readBtn").addEventListener("click",()=>{if(!lastResult)return;const utter=new SpeechSynthesisUtterance(reportText());utter.lang=lang==="gu"?"gu-IN":lang==="hi"?"hi-IN":"en-IN";speechSynthesis.cancel();speechSynthesis.speak(utter);});$("copyBtn").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(reportText());$("copyBtn").textContent="✓ કૉપી થયું";}catch(e){window.prompt("પરિણામ કૉપી કરો:",reportText());}});$("shareBtn").addEventListener("click",()=>{window.open("https://wa.me/?text="+encodeURIComponent(reportText()),"_blank","noopener");});}
 const search=$("learnSearch");if(search){const grid=$("learnGrid");function draw(){const q=search.value.toLowerCase();const list=(window.SCAM_CATEGORIES||[]).filter(c=>(c.nameGu+" "+c.nameEn+" "+c.explainGu+" "+c.keywords.join(" ")).toLowerCase().includes(q));$("learnCount").textContent=list.length+" પ્રકાર";grid.innerHTML=list.map(c=>'<article class="learn-card"><div class="learn-card-top"><span class="learn-icon">🛡️</span><span class="severity-tag">જોખમ સંકેત</span></div><h3>'+escapeHTML(c.nameGu)+'</h3><p>'+escapeHTML(c.explainGu)+'</p><h4>ધ્યાનમાં રાખો</h4><ul><li>અજાણી લિંક અને નંબરથી સાવધાન રહો.</li><li>OTP, PIN કે પાસવર્ડ શેર ન કરો.</li><li>સત્તાવાર માધ્યમથી માહિતી ચકાસો.</li></ul><button class="text-button try-category" data-id="'+c.id+'">આ પ્રકાર વિશે તપાસો →</button></article>').join("");grid.querySelectorAll(".try-category").forEach(b=>b.addEventListener("click",()=>{location.href="index.html";}));}search.addEventListener("input",draw);draw();}
});
})();