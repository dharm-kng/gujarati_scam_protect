# Manual test checklist

Open `index.html` and test these cases. Scores can change if rules are tuned; expected category/level is the target behavior, not a guarantee.

1. `Dear customer your SBI account will be blocked today. Update KYC now: http://sbi-kyc-update.xyz` → 🔴 Bank KYC / phishing.
2. `Your OTP is 482913. Do not share it with anyone.` → 🟢 genuine OTP notice; not treated as a request.
3. `Congratulations! You won ₹25,00,000 in KBC. Pay ₹5,000 processing fee.` → 🔴 Lottery.
4. `Earn ₹5000 daily by liking videos. Join Telegram group.` → 🔴 Job task.
5. `Aapka parcel me drugs mila hai, CBI officer se video call par baat karo.` → 🔴 Digital arrest (transliterated phrases may need more keywords).
6. `Rs 500 debited from A/c XX1234 on 12-10 via UPI. Ref 123456.` → 🟢 normal alert.
7. `તમારું લાઇટ બિલ બાકી છે, આજે રાત્રે કનેક્શન કપાશે. આ નંબર પર કૉલ કરો 98XXXXXXXX` → 🔴 Electricity bill.
8. `Enter your UPI PIN to receive ₹2000 refund` → 🔴 UPI collect.
9. `Your e-challan of ₹500 is pending, pay at http://echallan-parivahan.top` → 🔴 E-challan / phishing.
10. `Hi Mom, this is my new number, urgent need money` → 🔴 Relative-in-trouble.

Also test empty input, emoji, Gujarati/Hindi/English mixtures, a long message, no URL, multiple URLs, keyboard navigation, mobile width, speech support, clipboard permission and all quiz answers.
